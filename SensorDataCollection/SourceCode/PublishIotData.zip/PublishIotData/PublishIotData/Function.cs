using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Amazon.Lambda.Core;
using Amazon.Lambda.Serialization;
using Amazon.Runtime;
using Amazon.IotData;
using Amazon.IoT;
using Newtonsoft.Json;
using Faker.Extensions;
using Amazon.IoT.Model;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace PublishIotData
{

    public class DeviceData
    {
        public string PatientID { get; set; }
        public string Timestamp { get; set; }
        public string Name { get; set; }
        public string DOB { get; set; }
        public string DeviceID { get; set; }
        public string Temp { get; set; }
        public string Pulse { get; set; }
        public string OxygenPercent { get; set; }
        public string Systolic { get; set; }
        public string Diastolic { get; set; }
    }

    public class SimulatorConfig
    {
        public int NumberOfMsgs { get; set;}
    }

    public class PublishIoTData
    {
        /// <summary>
        /// A lambda function that publishes simulated sensor data to AWS IoT Endpoint Address
        /// </summary>
        /// <param name="input"></param>
        /// <param name="context"></param>
        /// <returns></returns>

        //this fuction gets the AWS IoT Endpoint Address specific to the AWS Account in which this lambda function is executing
        private async Task<string> GetAWSIoTEndpointAddress()
        {
            Amazon.IoT.AmazonIoTClient AWSIoTClient = new AmazonIoTClient();
            DescribeEndpointResponse response = await AWSIoTClient.DescribeEndpointAsync();
            return response.EndpointAddress;
        }

        static string IoTendpointURL = string.Empty;
        static string IoTTopic = Environment.GetEnvironmentVariable("IoTTopic");

        Amazon.IotData.Model.PublishRequest publishRequest = new Amazon.IotData.Model.PublishRequest();
        Amazon.IotData.Model.PublishResponse publishResponse = null;

        private List<DeviceData> GetDeviceData(int nuberOfDeviceDataForSimulation)
        {
            List<DeviceData> deviceDataCollection = new List<DeviceData>();

            for (int i = 0; i < nuberOfDeviceDataForSimulation; i++)
            {
                DeviceData deviceData = new DeviceData();
                deviceData.PatientID = Faker.RandomNumber.Next(100, 999).ToString();
                deviceData.Timestamp = DateTime.UtcNow.ToString();
                deviceData.Name = Faker.Name.First() + " " + Faker.Name.Last();
                deviceData.DOB = DateTime.Now.ToShortDateString();
                deviceData.DeviceID = Faker.RandomNumber.Next(100, 999).ToString();
                deviceData.Temp = Faker.RandomNumber.Next(90, 110).ToString();
                deviceData.Pulse = Faker.RandomNumber.Next(20, 100).ToString();
                deviceData.OxygenPercent = Faker.RandomNumber.Next(10, 100).ToString();
                deviceData.Systolic = Faker.RandomNumber.Next(100, 200).ToString();
                deviceData.Diastolic = Faker.RandomNumber.Next(4, 1009).ToString();

                deviceDataCollection.Add(deviceData);
            }
            return deviceDataCollection;
        }

        public async Task<Amazon.IotData.Model.PublishResponse> PublishToTopic(SimulatorConfig simulatorConfig, ILambdaContext context)
        {
            Console.WriteLine(string.Format("Begin Processing ..."));

            //get the AWS IoT Endpointpoint URL specific to the AWS Account
            IoTendpointURL = await GetAWSIoTEndpointAddress();

            Console.WriteLine(string.Format("AWS IoT EndpointAddress URL = {0}", IoTendpointURL));

            AmazonIotDataClient ioTdataclient = new AmazonIotDataClient(IoTendpointURL);

            //get the Device Data Collection for Simulation
            int numberofSesorData = simulatorConfig.NumberOfMsgs;
            int i = 1;
            List<DeviceData> deviceDataCollection = GetDeviceData(numberofSesorData);

            foreach (DeviceData devicedata in deviceDataCollection)
            {
                Console.WriteLine(string.Format("Processing {0} of {1} Sesnor Messages", i, numberofSesorData));
                string dataJSON = JsonConvert.SerializeObject(devicedata);
                byte[] dataAsBytes = Encoding.UTF8.GetBytes(dataJSON);

                using (MemoryStream memoryStream = new MemoryStream(dataAsBytes))
                {
                    try
                    {
                        publishRequest.Payload = memoryStream;
                        publishRequest.Qos = 0;
                        publishRequest.Topic = IoTTopic;
                        publishResponse = await ioTdataclient.PublishAsync(publishRequest);
                        Console.WriteLine(string.Format("Successfully published data = {0} to Topic = {1}", dataJSON, IoTTopic));
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(string.Format("Failed to Publish data = {0} to Topic {1} at AWSIoTEnpointAddressURL {2}. Exception: {3}", dataJSON, IoTTopic, IoTendpointURL, ex.Message));
                    }
                }
                i++;
            }
            return publishResponse;
        }
    }
}

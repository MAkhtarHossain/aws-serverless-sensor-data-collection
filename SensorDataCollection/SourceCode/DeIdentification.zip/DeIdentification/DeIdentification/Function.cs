using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.IO;
using System.Text;

using Amazon.Lambda.Core;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Amazon.KinesisFirehose;
using Amazon.KinesisFirehose.Model;
using Newtonsoft.Json;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace DeIdentification
{
    public class DeviceData
    {
        public string PatientID { get; set; }
        public string Timestamp { get; set; }
        public string Name { get; set; }
        public string DOB { get; set; }
        public string DeviceID { get; set; }
        public string Temp { get; set; }
        public string Pulse { get; set; }
        public string OxygenPercent { get; set; }
        public string Systolic { get; set; }
        public string Diastolic { get; set; }
    }

    public class Function
    {
        private string TableName = Environment.GetEnvironmentVariable("TableName");
        private string DeliveryStream = Environment.GetEnvironmentVariable("DeliveryStream");
        AmazonDynamoDBClient dynamoDBClient = new AmazonDynamoDBClient();

        /// <summary>
        /// This function does two things:
        /// 1. Removes from the incoming record DeviceData the Patient Name and DOB
        /// 2. Puts Into DynamoDb Table - PatientID, Timestamp, Patient Name and DOB
        /// </summary>
        /// <param name="customer"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task FunctionHandler(DeviceData devicedata, ILambdaContext context)
        {
            //Write Log to Cloud Watch using Console.WriteLline.    
            Console.WriteLine("Execution started for function -  {0} at {1}",
                                context.FunctionName, DateTime.Now);

            //Create Table if it Does Not Exists
            Console.WriteLine("Create DynamoDB Tanble: {0} - if the table does not exists", TableName);
            await CreateTable(dynamoDBClient, TableName);

            // Insert record in dynamodbtable  
            Console.WriteLine("Insert record in the table");

            await dynamoDBClient.PutItemAsync(TableName, new Dictionary<string, AttributeValue>
            {
                { "PatientID", new AttributeValue(devicedata.PatientID) },
                { "Timestamp", new AttributeValue(devicedata.Timestamp)},
                { "Name", new AttributeValue(devicedata.Name)},
                { "DOB", new AttributeValue(devicedata.DOB)}
            });

            //remove from the DeviceData PHI / PII Data - Patient Name and DOB
            Console.WriteLine(string.Format("De-Identification of Patent Name and DOB"));
            devicedata.Name = "";
            devicedata.DOB = "";
            Console.WriteLine(string.Format("DeliveryStreamName = {0}", DeliveryStream));
            Console.WriteLine(string.Format("devicedata.Name = {0}", devicedata.Name));
            Console.WriteLine(string.Format("devicedata.DOB = {0}", devicedata.DOB));

            string dataAsJson = JsonConvert.SerializeObject(devicedata) + Environment.NewLine;
            byte[] dataAsBytes = Encoding.UTF8.GetBytes(dataAsJson);
            using (MemoryStream memoryStream = new MemoryStream(dataAsBytes))
            {
                try
                {
                    PutRecordRequest putRecordRequest = new PutRecordRequest();
                    putRecordRequest.DeliveryStreamName = DeliveryStream;

                    Amazon.KinesisFirehose.Model.Record record = new Amazon.KinesisFirehose.Model.Record();
                    record.Data = memoryStream;
                    putRecordRequest.Record = record;

                    AmazonKinesisFirehoseClient firehoseClient = new AmazonKinesisFirehoseClient();
                    PutRecordResponse responseRecord = await firehoseClient.PutRecordAsync(putRecordRequest);
                    Console.WriteLine(string.Format("Successfull in putting data into DeliveryStream = {0}. Status = {1}, RecordId = {2}", putRecordRequest.DeliveryStreamName, responseRecord.HttpStatusCode.ToString(), responseRecord.RecordId));
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Failed to send record {0} to Kinesis Delivery Stream. Exception: {1}", dataAsJson, ex.Message);
                }
            }

            //Write Log to cloud watch using context.Logger.Log Method  
            Console.WriteLine(string.Format("Finished execution for function -- {0} at {1}",
                               context.FunctionName, DateTime.Now));
            return;
        }

        //Create Table if it does not exist  
        private async Task CreateTable(IAmazonDynamoDB amazonDynamoDBclient, string tableName)
        {
            //Write Log to Cloud Watch using LambdaLogger.Log Method  
            Console.WriteLine(string.Format("Creating {0} Table", tableName));

            var tableCollection = await amazonDynamoDBclient.ListTablesAsync();

            if (!tableCollection.TableNames.Contains(tableName))
                await amazonDynamoDBclient.CreateTableAsync(new CreateTableRequest
                {
                    TableName = tableName,
                    KeySchema = new List<KeySchemaElement> {
                            new KeySchemaElement { AttributeName="PatientID",  KeyType= KeyType.HASH },
                            new KeySchemaElement { AttributeName="Timestamp",  KeyType= KeyType.RANGE}
                    },

                    AttributeDefinitions = new List<AttributeDefinition> {
                      new AttributeDefinition { AttributeName="PatientID", AttributeType="S" },
                      new AttributeDefinition { AttributeName ="Timestamp",AttributeType="S"}

                    },

                    ProvisionedThroughput = new ProvisionedThroughput
                    {
                        ReadCapacityUnits = 5,
                        WriteCapacityUnits = 5
                    },
                });
        }
    }
}
